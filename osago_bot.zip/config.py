BOT_TOKEN = 'ВАШ_ТОКЕН_БОТА'
ADMIN_ID = 123456789
